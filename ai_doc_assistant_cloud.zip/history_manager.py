class HistoryManager:
    def __init__(self):
        self.sessions_dir = "sessions"
